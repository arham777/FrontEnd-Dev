from django.shortcuts import render
from rest_framework import generics
from authapi.serializers import SignUpSerializer
from django.contrib.auth.models import User
# Create your views here.

class SignUpView(generics.CreateAPIView):
  queryset = User.objects.all() 
  serializer_class = SignUpSerializer

